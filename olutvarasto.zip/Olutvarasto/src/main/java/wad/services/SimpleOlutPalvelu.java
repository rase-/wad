/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wad.services;

import wad.domain.Olut;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author tonykova
 */
public class SimpleOlutPalvelu implements OlutPalvelu{
    HashMap<Integer, Olut> oluet = new HashMap<Integer, Olut>();
    private static int LASKURI = 0;
    
    @Override
    public Olut lisaaOlut(Olut olut) {
        olut.setId(LASKURI);
        LASKURI++;
        oluet.put(olut.getId(), olut);
        return olut;
    }

    @Override
    public void poistaOlut(int tunnus) {
        oluet.remove(tunnus);
    }

    @Override
    public Olut muokkaaTaiLisaaOlut(int tunnus, Olut olut) {
        olut.setId(tunnus);
        Olut poistettava = oluet.remove(tunnus);
        oluet.put(tunnus, olut);
        return poistettava;
    }

    @Override
    public Olut annaOlut(int tunnus) {
        return oluet.get(tunnus);
    }

    @Override
    public List<Olut> listaaOluet() {
        return (List<Olut>) oluet.values();
    }
    
}
